from distutils.core import setup
setup(name='ai42',
      version='1.0.0',
      py_modules=['logging', 'progressbar'],
      )
